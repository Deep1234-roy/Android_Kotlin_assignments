package com.example.fragmentdatatransfer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.replace

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //set the first fragment as launcher fragment
        supportFragmentManager.beginTransaction().replace<FirstFragment>(R.id.nav_container).commit()
    }
}