package com.example.recyclerviewdemo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerviewdemo.model.Contact

class ContactsAdapter(private val mContacts:List<Contact>): RecyclerView.Adapter<ContactsAdapter.ContactViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        val contactView = LayoutInflater.from(parent.context).inflate(R.layout.item_contact,parent,false)
        return ContactViewHolder(contactView)
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        val contact: Contact = mContacts.get(position)
        val personName = holder.nameTextView
        personName.setText(contact.name)
        val msgBtn = holder.messageButton
        msgBtn.text = if(contact.isOnline) "Message" else "Offline"
        msgBtn.isEnabled = contact.isOnline
    }

    override fun getItemCount(): Int {
        return mContacts.size
    }

    inner class ContactViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        val nameTextView : TextView = itemView.findViewById(R.id.contact_name)
        val messageButton : Button = itemView.findViewById(R.id.message_button)
    }
}