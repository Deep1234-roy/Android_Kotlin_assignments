package com.example.userlist

data class companyDetails(
    val name: String,
    val catchPhrase: String,
    val bs: String
)
