package com.example.userlist

data class AddressData(
    val street:String,
    val suite:String,
    val city:String,
    val zipcode:String,
    val geo: List<geoData>
)
