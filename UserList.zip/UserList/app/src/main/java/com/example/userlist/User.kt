package com.example.userlist

data class User(
    val id: Int,
    val name: String,
    val username: String,
//    val email: String,
//    val address: List<AddressData>,
//    val phone: String,
//    val website: String,
//    val company: List<companyDetails>
)

object supplier{
    val userList = listOf<User>(
        User(1,"Leanne Graham","Bret"))
}

