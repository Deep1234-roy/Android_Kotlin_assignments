package com.example.userlist

data class geoData(
    val lat: String,
    val lng: String
)
