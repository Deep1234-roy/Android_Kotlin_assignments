package com.example.userlist.network

import com.example.userlist.Model.User
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
interface ApiInterface {
    @GET("users")
    fun GetAllUsers(): Call<List<User>>

}