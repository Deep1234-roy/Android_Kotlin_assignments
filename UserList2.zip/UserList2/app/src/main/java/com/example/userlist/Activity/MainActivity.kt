package com.example.userlist.Activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.userlist.Model.User
import com.example.userlist.R
import com.example.userlist.UserAdapter
import com.example.userlist.databinding.ActivityDetailsBinding
import com.example.userlist.databinding.ActivityMainBinding
import com.example.userlist.viewmodel.UserViewModel


class MainActivity : AppCompatActivity() {
    private var viewModel: UserViewModel? = null
    lateinit var Uadapter: UserAdapter
    private var binding: ActivityMainBinding?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        viewModel = UserViewModel()
        setContentView(binding?.root)
        Uadapter = UserAdapter(this@MainActivity)
        viewModel = ViewModelProviders.of(this)[UserViewModel::class.java]
        viewModel?.init()
        viewModel?.getUserResponseLiveData()?.observe(this, object : Observer<List<User>> {
            override fun onChanged(userList: List<User>) {
                Uadapter.setResults(userList)
            }
        })
        binding?.recyclerView.apply {
            binding?.recyclerView?.adapter=Uadapter
            binding?.recyclerView?.layoutManager=LinearLayoutManager(this@MainActivity)
        }
    }
}

