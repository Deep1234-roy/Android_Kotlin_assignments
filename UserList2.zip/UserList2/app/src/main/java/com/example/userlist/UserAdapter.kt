package com.example.userlist

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.RecyclerView
import com.example.userlist.Activity.DetailsActivity
import com.example.userlist.Model.User
import com.example.userlist.databinding.UserRowBinding

class UserAdapter( val context: Context) : RecyclerView.Adapter<UserAdapter.ViewHolder>() {
    private var users: List<User> = ArrayList<User>()
    inner class ViewHolder(val binding: UserRowBinding): RecyclerView.ViewHolder(binding.root) {
        //val Name: TextView = itemView.findViewById(R.id.Name)
        //val Email: TextView = itemView.findViewById(R.id.emailAddress)
        var phone: String = ""
        var username: String = ""
        var website: String = ""
        var street: String = ""
        var suite: String = ""
        var companyName: String = ""
        fun bindItem(user: User){
            binding.Name.text=user.name
            binding.emailAddress.text = user.email
        }
        init {
            itemView.setOnClickListener {
                val user = users[adapterPosition]
                val intent = Intent(context, DetailsActivity::class.java)
                intent.putExtra("users",user)
                context.startActivity(intent)
            }
        }
    }

    fun setResults(results: List<User>) {
        users = results
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = UserRowBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        //val view = LayoutInflater.from(parent.context).inflate(R.layout.user_row,parent,false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = users[position]
        holder.bindItem(user)
        holder.phone = user.phone
        holder.username = user.username
        holder.website = user.website
        holder.street = user.address.street
        holder.suite = user.address.suite
        holder.companyName = user.company.name

    }
    override fun getItemCount(): Int {
        return users.size
    }
}
