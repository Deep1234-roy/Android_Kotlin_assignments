package com.example.userlist.Repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.userlist.Model.User
import com.example.userlist.network.ApiClient
import com.example.userlist.network.ApiInterface
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class UserRepository {

    lateinit var ResponseLiveData: MutableLiveData<List<User>>
    lateinit var apiClient: ApiClient
    init {
        ResponseLiveData = MutableLiveData<List<User>>()
        apiClient = ApiClient()

        apiClient.getApiServices()?.GetAllUsers()?.enqueue(object :Callback<List<User>>{
            override fun onResponse(call: Call<List<User>>, response: Response<List<User>>) {
                if(response.body()!=null){
                    ResponseLiveData.postValue(response.body())
                }
            }

            override fun onFailure(call: Call<List<User>>, t: Throwable) {
                ResponseLiveData.postValue(null)
            }

        })
    }

    fun getUsersResponseLiveData(): LiveData<List<User>> {
        return ResponseLiveData
    }


}