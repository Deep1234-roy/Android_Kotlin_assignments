package com.example.userlist.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.get
import com.example.userlist.Model.User
import com.example.userlist.databinding.ActivityDetailsBinding

class DetailsActivity : AppCompatActivity() {
    lateinit var binding: ActivityDetailsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailsBinding.inflate(layoutInflater)
//        setContentView(R.layout.activity_details)
        setContentView(binding.root)
        val users = intent.getSerializableExtra("users") as User
        Log.i("User Information",users.toString())
        //Data Binding Concepts
        binding.viewmodel = users.name
        //View Binding Concepts
        binding.txvPhone.text = users.phone
        binding.txvEmail.text = users.email
        binding.txvUserName.text= users.username
        binding.txvWebsite.text = users.website
        binding.txvStreetName.text = users.address.street
        binding.txvSuite.text = users.address.suite
        binding.txvCompanyName.text = users.company.name







//        Using FindViewById to get the textView
//        val show_userName :TextView = findViewById(R.id.txvName)
//        val show_phone: TextView = findViewById(R.id.txvPhone)
//        var show_mail: TextView = findViewById(R.id.txvEmail)
//        val show_uName : TextView = findViewById(R.id.txvUserName)
//        val show_website : TextView = findViewById(R.id.txvWebsite)
//        val show_Street : TextView = findViewById(R.id.txvStreetName)
//        val show_suite: TextView = findViewById(R.id.txvSuite)
//        val show_company_name : TextView = findViewById(R.id.txvCompanyName)
        //View Binding Concepts
//        binding.txvName.text = users.name
//        show_userName.text = users.name
//        show_phone.text = users.phone
//        show_mail.text = users.email
//        show_uName.text = users.username
//        show_website.text = users.website
//        show_Street.text = users.address.street
//        show_suite.text = users.address.suite
//        show_company_name.text = users.company.name
    }
}