package com.example.userlist.network

import androidx.lifecycle.MutableLiveData
import com.example.userlist.Model.User
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ApiClient {
    private val BASE_URL = "https://jsonplaceholder.typicode.com/"
    private var ApiService: ApiInterface? = null


    init {

        ApiService = Retrofit.Builder().baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiInterface::class.java)
    }

    fun getApiServices(): ApiInterface?{
        return ApiService
    }
}