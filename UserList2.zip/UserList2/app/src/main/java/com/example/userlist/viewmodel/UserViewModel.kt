package com.example.userlist.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.userlist.Model.User
import com.example.userlist.Repository.UserRepository
import com.example.userlist.network.ApiInterface
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class UserViewModel:ViewModel() {
    lateinit var userRepository: UserRepository
    lateinit var UsersResponseLiveData: LiveData<List<User>>

    fun init() {
        userRepository = UserRepository()
        UsersResponseLiveData = userRepository.getUsersResponseLiveData()

    }
        fun getUserResponseLiveData(): LiveData<List<User>> {
        return UsersResponseLiveData
    }

}