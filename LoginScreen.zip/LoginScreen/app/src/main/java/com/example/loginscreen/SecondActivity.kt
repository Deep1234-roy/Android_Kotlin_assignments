package com.example.loginscreen

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SecondActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_activity)
        val showtext = findViewById<TextView>(R.id.txvUserName)
        val bundle: Bundle? = intent.extras
        val msg = bundle!!.getString("user_name")
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        showtext.text = msg
    }
}