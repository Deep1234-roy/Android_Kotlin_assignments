package com.example.loginscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button: Button=findViewById(R.id.button)
        val shareButton : Button=findViewById(R.id.btnShare)
        val recyclerViewButtom : Button=findViewById(R.id.btnRecycler)
        val Email: TextView=findViewById(R.id.editTextTextEmailAddress)
        val password: TextView=findViewById(R.id.editTextTextPassword)
        button.setOnClickListener{
            if(Email.text.isNullOrBlank() && password.text.isNullOrBlank()){
                Toast.makeText(this, "Please fill all Required Fields", Toast.LENGTH_SHORT).show()
            }else{
                val message:String = Email.text.toString()
                val intent = Intent(this,SecondActivity::class.java)
                intent.putExtra("user_name",message)
                startActivity(intent)
            }
        }

        shareButton.setOnClickListener {
            val intent = Intent()
            val message:String = Email.text.toString()
            intent.action = Intent.ACTION_SEND
            intent.putExtra(Intent.EXTRA_TEXT,message)
            intent.type="text/plain"
            startActivity(Intent.createChooser(intent,"Please Choose App : - "))
        }
        recyclerViewButtom.setOnClickListener{
            val intent = Intent(this,HobbiesActivity::class.java)
            startActivity(intent)
        }



    }
}