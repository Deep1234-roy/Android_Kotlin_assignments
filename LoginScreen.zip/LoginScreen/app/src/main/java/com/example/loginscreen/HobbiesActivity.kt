package com.example.loginscreen

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HobbiesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hobbies)

        val layoutManager = LinearLayoutManager(this)
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        val view = findViewById<RecyclerView>(R.id.recyclerView)
        view.layoutManager = layoutManager
        val adapter = HobbiesAdapter(this,Supplier.hobbiesList)
        view.adapter = adapter
    }
}