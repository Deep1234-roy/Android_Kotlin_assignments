package com.example.loginscreen

data class Hobby(var title:String)

object Supplier
{
    val hobbiesList = listOf<Hobby>(
        Hobby("Swimming"),
        Hobby("Dancing"),
        Hobby("Gaming"),
        Hobby("Gardening"),
        Hobby("Climbing"),
        Hobby("Cycling"),
        Hobby("Internet Surfing"),
        Hobby("Playing Cricket"),
        Hobby("Travelling"),
        Hobby("Singing"),
        Hobby("Stand Up Comedy"),
        Hobby("Sleeping"),
        Hobby("Walking"),
        Hobby("Reading"),
        )
}