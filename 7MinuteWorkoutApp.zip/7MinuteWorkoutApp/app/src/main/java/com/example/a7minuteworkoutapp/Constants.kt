package com.example.a7minuteworkoutapp

object Constants {
    fun defaultExerciseList():ArrayList<ExerciseModel>{
        val exerciseList = ArrayList<ExerciseModel>()
        val Jumping_jacks = ExerciseModel(
            1,
            "Jumping Jacks",
            R.drawable.jumpingjack,
            false,
            false
        )
        exerciseList.add(Jumping_jacks)

        val Squats = ExerciseModel(
            2,
            "Squats",
            R.drawable.squat,
            false,
            false
        )
        exerciseList.add(Squats)

        val Lunges = ExerciseModel(
            3,
            "Lunges",
            R.drawable.lunges,
            false,
            false
        )
        exerciseList.add(Lunges)

        val Plank = ExerciseModel(
            4,
            "Plank",
            R.drawable.plank,
            false,
            false
        )
        exerciseList.add(Plank)

        val Push_ups = ExerciseModel(
            5,
            "Push Ups",
            R.drawable.pushup,
            false,
            false
        )
        exerciseList.add(Push_ups)

        val Tricep_dip_on_chair = ExerciseModel(
            6,
            "Tricep Dip On Chair",
            R.drawable.tricep,
            false,
            false
        )
        exerciseList.add(Tricep_dip_on_chair)


        return exerciseList
    }
}