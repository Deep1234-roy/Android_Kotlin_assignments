package com.example.a7minuteworkoutapp

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.a7minuteworkoutapp.databinding.ItemHistoryRowBinding

class HistoryAdapter(private val items: ArrayList<String>):RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {
    class ViewHolder(private val historyRowBinding: ItemHistoryRowBinding): RecyclerView.ViewHolder(historyRowBinding.root) {
        val llHistoryItemMain = historyRowBinding.llHistoryItemMain
        val tvPosition = historyRowBinding.tvPosition
        val tvItem = historyRowBinding.tvItem
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemViewHolder = ItemHistoryRowBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ViewHolder(itemViewHolder)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val dates = items[position]
        holder.tvPosition.text = (position + 1).toString()
        holder.tvItem.text = dates

        if(position % 2 == 0){
            holder.llHistoryItemMain.setBackgroundColor(Color.parseColor("#EBEBEB"))
        }else{
            holder.llHistoryItemMain.setBackgroundColor(Color.parseColor("#FFFFFF"))
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }
}