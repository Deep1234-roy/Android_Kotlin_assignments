package com.example.a7minuteworkoutapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.a7minuteworkoutapp.databinding.ActivityBmiactivityBinding
import java.math.BigDecimal
import java.math.RoundingMode

class BMIActivity : AppCompatActivity() {
    companion object{
        private const val METRICS_UNIT_VIEW = "METRIC_UNIT_VIEW"
        private const val US_UNIT_VIEW = "US_UNIT_VIEW"
    }
    private var currentVisibleView : String = METRICS_UNIT_VIEW
    private var binding : ActivityBmiactivityBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBmiactivityBinding.inflate(layoutInflater)
        setContentView(binding?.root)
//        setSupportActionBar(binding?.toolbarBmi)
        if(supportActionBar != null){
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            supportActionBar?.title = "Calculate BMI"
        }
        binding?.toolbarBmi?.setNavigationOnClickListener {
            onBackPressed()
        }

        makeMetricUnitVisible()
        binding?.rgUnits?.setOnCheckedChangeListener{_,checkId:Int->
            if(checkId == R.id.rbMetricUnits){
                makeMetricUnitVisible()
            }else{
                makeUSUnitVisible()
            }
        }
        binding?.btnCalculateUnits?.setOnClickListener {
            if(validateMetricUnits()){
                val heightValue : Float = binding?.etMetricUnitHeight?.text.toString().toFloat() / 100
                val weightValue : Float = binding?.etMetricUnitWeight?.text.toString().toFloat()
                val bmi = weightValue / (heightValue*heightValue)
                displayBmiResults(bmi)
            }else{
                Toast.makeText(
                    this@BMIActivity,"Please Enter valid Values!!",Toast.LENGTH_LONG
                ).show()
            }
        }

    }
    private fun makeMetricUnitVisible(){
        currentVisibleView = METRICS_UNIT_VIEW
        binding?.tliMetricUnitWeight?.visibility = View.VISIBLE
        binding?.tliMetricUnitHeight?.visibility = View.VISIBLE
        binding?.MetricUSUnitHeightFeet?.visibility = View.GONE
        binding?.MetricUSUnitWeightFeet?.visibility = View.GONE

        binding?.etMetricUnitHeight?.text!!.clear()
        binding?.etMetricUnitWeight?.text!!.clear()
        binding?.llDisplayBMIResult?.visibility = View.INVISIBLE
    }

    private fun makeUSUnitVisible(){
        currentVisibleView = US_UNIT_VIEW
        binding?.tliMetricUnitWeight?.visibility = View.GONE
        binding?.tliMetricUnitHeight?.visibility = View.GONE
        binding?.etMetricUnitWeight?.visibility = View.VISIBLE
        binding?.MetricUSUnitHeightFeet?.visibility = View.VISIBLE
        binding?.MetricUSUnitWeightFeet?.visibility = View.VISIBLE

        binding?.etUsUnitHeightFeet?.text!!.clear()
        binding?.etUsUnitWeightFeet?.text!!.clear()
        binding?.llDisplayBMIResult?.visibility = View.INVISIBLE
    }
    private fun displayBmiResults(bmi:Float){
        val bmiLabel: String
        val bmiDesc: String

        if(bmi.compareTo(15f) <= 0){
            bmiLabel = "Very severly Underweight"
            bmiDesc = "OOPS! you really need to take care yourself! EAT MORE!!"
        }else if(bmi.compareTo(15f) > 0 && bmi.compareTo(16f) <= 0){
            bmiLabel = "Severly Underweight"
            bmiDesc = "OOPS! you really need to take care yourself! EAT MORE!!"
        }else if(bmi.compareTo(16f) > 0 && bmi.compareTo(18.5f) <= 0){
            bmiLabel = "Underweight"
            bmiDesc = "OOPS! you really need to take care yourself! EAT MORE!!"
        }else if(bmi.compareTo(18.5f) > 0 && bmi.compareTo(25f) <= 0){
            bmiLabel = "Normal"
            bmiDesc = "Congratulations!! you are in a good shape"
        }else if(bmi.compareTo(25f) > 0 && bmi.compareTo(30f) <= 0){
            bmiLabel = "Overweight"
            bmiDesc = "OOPS! you really need to take care yourself! Start the Workout!!"
        }else if(bmi.compareTo(30f) > 0 && bmi.compareTo(35f) <= 0){
            bmiLabel = "Obese class | Moderately Obese"
            bmiDesc = "OOPS! you really need to take care yourself! Start the Workout!!"
        }else if(bmi.compareTo(35f) > 0 && bmi.compareTo(40f) <= 0){
            bmiLabel = "Obese class | Severely Obese"
            bmiDesc = "OOPS! you really need to take care yourself! Start the Workout!!"
        }else{
            bmiLabel = "Obese class | Very Severely Obese"
            bmiDesc = "OOPS! you really need to take care yourself! Act Now!!"
        }

        val bmiValue = BigDecimal(bmi.toDouble()).setScale(2,RoundingMode.HALF_EVEN).toString()
        binding?.tvBMIValue?.text = bmiValue
        binding?.tvBMIType?.text = bmiLabel
        binding?.tvBMIDesc?.text = bmiDesc
        binding?.llDisplayBMIResult?.visibility = View.VISIBLE
    }
    private fun validateMetricUnits():Boolean{
        var isValid = true
        if(binding?.etMetricUnitWeight?.text.toString().isEmpty()){
            isValid = false
        }else if(binding?.etMetricUnitHeight?.text.toString().isEmpty()){
            isValid = false
        }
        return isValid
    }
}