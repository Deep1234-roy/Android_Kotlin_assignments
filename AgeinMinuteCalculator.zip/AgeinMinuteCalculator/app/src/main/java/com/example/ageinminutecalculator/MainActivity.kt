package com.example.ageinminutecalculator

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private var tvSelectedDate : TextView? = null
    private var tvAgeInMinutes : TextView? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnDatePicker : Button = findViewById(R.id.btnDatePicker)
        tvSelectedDate = findViewById(R.id.tvSelectedDate)
        tvAgeInMinutes = findViewById(R.id.tvAgeInMinutes)
        btnDatePicker.setOnClickListener {
            clickDatePicker()
        }

    }

    fun clickDatePicker(){
        val myCalender = Calendar.getInstance()
        val year = myCalender.get(Calendar.YEAR)
        val month = myCalender.get(Calendar.MONTH)
        val day = myCalender.get(Calendar.DAY_OF_MONTH)
        val dpd = DatePickerDialog(this,
            DatePickerDialog.OnDateSetListener { view, SelectedYear, SelectedMonth, SelectedDay ->
                Toast.makeText(this, "Year is $SelectedYear, Month is ${SelectedMonth+1}, Day is $SelectedDay", Toast.LENGTH_SHORT).show()
                val selectedDate = "$SelectedDay/${SelectedMonth+1}/$SelectedYear"
                tvSelectedDate?.text = selectedDate
                val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)
                val theDate = sdf.parse(selectedDate)
//                val selectedDateInMinutes = theDate.time / 60000
//                val currentDate = sdf.parse(sdf.format(System.currentTimeMillis()))
//                val currentDateInMinutes = currentDate.time / 60000
//                val diffInMinutes = currentDateInMinutes - selectedDateInMinutes
//                tvAgeInMinutes?.text = diffInMinutes.toString()
                val selectedDateInYear = theDate.year
                val currentDate = sdf.parse(sdf.format(System.currentTimeMillis()))
                val currentDateinYear = currentDate.year
                val diffInYear = currentDateinYear - selectedDateInYear
                tvAgeInMinutes?.text = "${diffInYear.toString()} years of Old"
            },
        year,
        month,
        day
        )
        dpd.datePicker.maxDate = System.currentTimeMillis() - 86400000
        dpd.show()

    }
}