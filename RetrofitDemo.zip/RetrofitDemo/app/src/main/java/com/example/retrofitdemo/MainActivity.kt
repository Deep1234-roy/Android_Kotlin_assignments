package com.example.retrofitdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

const val BASE_URL = "https://jsonplaceholder.typicode.com/"
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        getMyData()

    }

    private fun getMyData() {
        val retroFitBuilder = Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl(BASE_URL)
            .build()
            .create(ApiService::class.java)

        val retrofitData = retroFitBuilder.getPosts()

        retrofitData.enqueue(object : Callback<List<Users>?> {
            override fun onResponse(call: Call<List<Users>?>, response: Response<List<Users>?>) {
                val responseBody = response.body()!!
                val myStringBilder = StringBuilder()
                for(myData in responseBody){
                    myStringBilder.append(myData.title)
                    myStringBilder.append("\n")
                }
                val textViewID = findViewById<TextView>(R.id.txtId)
                textViewID.text = myStringBilder
            }

            override fun onFailure(call: Call<List<Users>?>, t: Throwable) {
                Log.d("MainActivity","${t.message.toString()}")
            }
        })
    }

}

