package com.example.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val MyClickBtn = findViewById<Button>(R.id.Mybutton)
        val MyTextView = findViewById<TextView>(R.id.textView)
        var timeCount: Int = 0
        MyClickBtn.setOnClickListener {
            timeCount += 1
            MyTextView.text = timeCount.toString()
            Toast.makeText(this,"Clicking ${timeCount} times!!",Toast.LENGTH_LONG).show()
        }
    }
}