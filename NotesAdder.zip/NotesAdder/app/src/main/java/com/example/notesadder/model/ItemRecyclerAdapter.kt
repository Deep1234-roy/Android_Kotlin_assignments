package com.example.notesadder.model

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.notesadder.R
import com.example.notesadder.viewModel.MainViewModel

class ItemRecyclerAdapter(val viewmodel: MainViewModel, val blogList: ArrayList<Blog>,val context: Context):RecyclerView.Adapter<ItemRecyclerAdapter.ItemsViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemsViewHolder {
        var root = LayoutInflater.from(parent.context).inflate(R.layout.item_view,parent,false)
        return ItemsViewHolder(root)
    }

    override fun onBindViewHolder(holder: ItemsViewHolder, position: Int) {
        holder.bind(blogList.get(position))
    }

    override fun getItemCount(): Int {
        if(blogList.size == 0){
            Toast.makeText(context,"List is empty",Toast.LENGTH_LONG).show()
        }else{

        }
        return blogList.size
    }

    inner class ItemsViewHolder(private val binding: View): RecyclerView.ViewHolder(binding) {
        fun bind(blog:Blog){
            binding.findViewById<TextView>(R.id.txvTitle).text = blog.title
            binding.findViewById<ImageButton>(R.id.delete).setOnClickListener {
                viewmodel.remove(blog)
                notifyItemRemoved(blogList.indexOf(blog))
            }
        }
    }


}