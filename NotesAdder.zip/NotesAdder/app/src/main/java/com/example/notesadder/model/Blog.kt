package com.example.notesadder.model

data class Blog(
    var title:String
)
