package com.example.notesadder.view

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.notesadder.R
import com.example.notesadder.model.Blog
import com.example.notesadder.model.ItemRecyclerAdapter
import com.example.notesadder.viewModel.MainViewModel

class MainActivity : AppCompatActivity() {
    private var viewManager = LinearLayoutManager(this)
    private var viewModel: MainViewModel?=null
    private lateinit var mainRecyclerView: RecyclerView
    private lateinit var button: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mainRecyclerView=findViewById(R.id.recycler)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        button = findViewById(R.id.button)
        button.setOnClickListener {
            addData()
        }
        initialiseAdapter()
    }

    private fun initialiseAdapter() {
        mainRecyclerView.layoutManager = viewManager
        observeData()
    }

    private fun observeData() {
        viewModel?.lst?.observe(this, Observer {
            Log.i("data",it.toString())
            mainRecyclerView.adapter = ItemRecyclerAdapter(viewModel!!,it,this)
        })
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun addData() {
        val txtPlace = findViewById<EditText>(R.id.titletxt)
        val title = txtPlace.text.toString()
        if(title.isBlank()){
            Toast.makeText(this,"Enter Value",Toast.LENGTH_LONG).show()
        }else{
            val blog = Blog(title)
            viewModel?.add(blog)
            txtPlace.text.clear()
            mainRecyclerView.adapter?.notifyDataSetChanged()
        }


    }
}