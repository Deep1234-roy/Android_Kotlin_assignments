package com.example.weatherapp.model

import java.io.Serializable

data class Clouds(
    val all:Int
): Serializable
