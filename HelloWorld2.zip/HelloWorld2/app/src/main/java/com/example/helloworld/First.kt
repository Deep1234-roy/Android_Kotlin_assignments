package com.example.helloworld

fun main(args: Array<String>){
    print("Hello World")
}