package com.example.kotlinbasics

fun main(){
    val months = listOf<String>("Jan","Feb","Mar","Apr")
    val anyTypeList = listOf<Any>("May",78,"June",89.90,true,false,"July")
    println(anyTypeList.size)
    for(mon in months){
        println(mon)
    }

    val addMonth = months.toMutableList()
    val newMonth = arrayOf("Aug","sep","Oct","Nov")
    addMonth.addAll(newMonth)
    println(addMonth)

    println("----------------------------------")
    //create a MutableList of Particular type
    val days = mutableListOf<String>("Sun","Mon","Tues","Wed")
    days.add("Thurs")
    println(days)

    //override items in given list
    days[2]="Saturday"
    println(days)
    days.removeAt(3)
    println(days)
}