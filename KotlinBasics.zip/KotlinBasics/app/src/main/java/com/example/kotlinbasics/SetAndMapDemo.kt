package com.example.kotlinbasics

fun main(){
    //Set
    val fruits = setOf<String>("Mango","Banana","Apple","Mango")
    println(fruits.size)
    println(fruits)
    println(fruits.toSortedSet())
    val newFruits = fruits.toMutableList()
    newFruits.add("Water Melon")
    newFruits.add("Pear")
    println(newFruits.toSortedSet().elementAt(2))
    println(newFruits.elementAt(2))

    //Map
    val daysOfTheWeek = mapOf(1 to "Monday",2 to "Tuesday",3 to "Wednesday",4 to "Thursday")
    println(daysOfTheWeek[2])
    for(keys in daysOfTheWeek.keys){
        println("$keys is to ${daysOfTheWeek[keys]}")
    }

    val Newfruits = mapOf("Favourite" to Fruits("Apple",78.90),"OK" to Fruits("Grapes",19.77),"Medium" to Fruits("Pear",120.0))

}
data class Fruits(val name:String,val price:Double)