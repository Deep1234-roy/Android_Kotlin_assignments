package com.example.kotlinbasics

fun main(){
    val stringList: List<String> = listOf("Deep","Ayan","Chitra","Devraj","Payel")
    val mixedTypeList: List<Any> = listOf("Jenis",78,true,"ABC",89.90f,367.890)
    for(value in mixedTypeList){
        when(value){
            is Int -> println("Integer is : - $value")
            is String -> println("String is : - $value")
            is Float -> println("Float is : - $value")
            is Double -> println("Double is : - $value")
            is Boolean -> println("Boolean is : - $value")
        }
    }
    println("------------------------------------------------")
    println("Using If-Else")
    for(value in mixedTypeList){
        if(value is Int){
            println("Integer is : - $value")
        }else if(value is String){
            println("String is : - $value")
        }else if(value is Boolean){
            println("Boolean is : - $value")
        }else if(value is Float){
            println("Float is : - $value")
        }else if(value is Double){
            println("Double is : - $value")
        }else{
            println("Unknown Type")
        }
    }
    println("------------------------------------")
    val obj1 ="I have a Dream"
    if(obj1 !is String){
        println("Not a String")
    }else{
        println("Obj1 has ${obj1.length} length")
    }
    println("------------------------------------")
    //Explicit(Unsafe) casting using the as
    val str1:String = obj1 as String
    println(str1.length)
//    val obj2:Any = 1334
//    val str2: String = obj2 as String
//    println(str2)

    //Explicit(safe) casting using the as
    val obj3:Any = 1334
    val str3: String? = obj3 as? String
    println(str3)

}