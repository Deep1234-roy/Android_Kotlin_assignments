package com.example.kotlinbasics

fun main(){
    val arrayList = ArrayList<String>()
    arrayList.add("One")
    arrayList.add("two")
    for(i in arrayList){
        println(i)
    }

    val arrList: ArrayList<String> = ArrayList<String>(5)
    var list: MutableList<String> = mutableListOf<String>()
    list.add("One")
    list.add("two")
    arrayList.addAll(list)

    val itr = arrList.iterator()
    while(itr.hasNext()){
        println(itr.next())
    }

    /*
    Please write a program that adds five Numbers (Double) to an arrayList
    and then calculates the average of those numbers.
    Please use a for (in) loop in this exercise.
     */

    val doubleArrList: ArrayList<Double> = ArrayList<Double>()
    var newMutableList : MutableList<Double> = mutableListOf<Double>()
    newMutableList.add(10.00)
    newMutableList.add(20.00)
    newMutableList.add(30.00)
    newMutableList.add(40.00)
    newMutableList.add(50.00)
    doubleArrList.addAll(newMutableList)
    var sum: Double = 0.0
    var avg:Double = 0.0
    for(i in doubleArrList){
        sum+=i
        avg = sum/(doubleArrList.size)
    }
    println("Sum of five number is : - $sum")
    println("Average of five number is : - $avg")

}