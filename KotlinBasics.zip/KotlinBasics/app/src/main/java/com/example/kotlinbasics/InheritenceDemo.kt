package com.example.kotlinbasics


interface Drivable{
    val maxSpeed:Double
    fun drive():String
    fun Brake(){
        println("The Drivable is Braking!!")
    }
}
open class Vehicle(override val maxSpeed: Double,val name:String, val brand:String):Drivable{
    open var range:Double=0.0
    fun extendRange(amount:Double):Double{
        if(amount>0){
            range+=amount
        }
        return range
    }

    override fun drive(): String {
        return "Vehicle is driving!!"
    }

    open fun drive(distance:Double){
        println("Drove for $distance KM via Vehicle")
    }
}

class Bike(maxSpeed: Double,name: String,brand: String,batteryLife:Double):Vehicle(maxSpeed,name, brand){
    override var range = batteryLife * 3
    override fun drive(distance: Double) {
        println("Drove for $distance KM via Bike")
    }

    override fun Brake() {
        super.Brake()
        println("Bike is Braking as well!!")
    }
}

fun main(){
    var myVehicle = Vehicle(78.90,"A3","BMW")
    var myBike = Bike(50.0,"S-Model","Hero",78.9)
//    myVehicle.range=98.0
//    println(myVehicle.extendRange(50.0))
//    myVehicle.drive(120.9)
//    myBike.drive(79.90)
//    println(myBike.extendRange(26.90))
//    println(myBike.range)
//    println(myBike.drive(89.90))
    println(myVehicle.drive())
    myVehicle.Brake()
    myBike.Brake()
    myBike.drive()

}

