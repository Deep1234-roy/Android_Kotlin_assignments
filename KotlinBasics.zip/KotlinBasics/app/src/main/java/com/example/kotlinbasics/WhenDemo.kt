package com.example.kotlinbasics

fun main(){
    var season = 3
    when(season){
        1 -> println("Summer")
        2 -> println("Rainy Day")
        3 -> {
            println("Fall!!")
            println("Winter")
        }
        else -> println("Invalid Season!!")
    }

    var age = 23
    when(age){
        in 20..30 -> println("you can drink in US")
        in 16..19 -> println("you may vote")
        14,15 -> println("you are teenager")
        else -> println("No option is here")
    }

    var x: Any = 10
    when(x){
//        is Int -> println("$x is a Integer")
        !is Double -> println("$x is not a Double")
        is String -> println("$x is a String")
        else -> println("$x is none of the above type")
    }
}