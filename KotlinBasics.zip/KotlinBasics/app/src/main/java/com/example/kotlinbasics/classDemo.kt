package com.example.kotlinbasics

fun main(){
    var mobile1 = MobilePhone("Android","Samsung","Galaxy S20 Ultra")
    var mobile2 = MobilePhone("Android","Realme","Note 5 Pro")
    var mobile3 = MobilePhone("Android","MI","Redmi Note 5 Pro")
    mobile1.chargeBattery(70)
}
class MobilePhone(osName: String,brand:String,model:String){
    init{
        println("The phone $model from $brand uses $osName as its Operating System")
    }
    //Member variables
    var battery:Int=10
    fun chargeBattery(chargedBy: Int){
        println("The Phone had $battery% charge before!!")
        println("Now the Phone has ${battery+chargedBy}% of Charge!!")
        battery += chargedBy
    }

}