package com.example.kotlinbasics

fun main(){
    val num1: IntArray = intArrayOf(1,2,3,4,5,6)
    val num2= intArrayOf(3,48,4,9,47)
    val num3=arrayOf(89,27.87,3,2,7)

    println(num3.contentToString())
    for(ele in num2){
        println(ele)
    }
    println("Initial Values : - ${num2.contentToString()}")
    num2[3]=48
    num2[0]=1
    num2[1]=99
    println("Changed Values : - ${num2.contentToString()}")

    val days = arrayOf("Sun","Mon","Tues","Wed","Thurs","Fri","Sat")
    println(days.contentToString())

    val fruits = arrayOf(Fruit("Apple",120.90), Fruit("Banana",78.80),Fruit("Grapes",30.90))
    println(fruits.contentToString())
    for(fruit in fruits){
        println("${fruit.name}")
    }
    for(index in fruits.indices){
        println("${fruits[index].name} is in index $index")
    }

    val mixedArray = arrayOf("Sun","Mon","Tues",78,90.90,Fruit("Orange",150.90))
    println(mixedArray.contentToString())
}
data class Fruit(val name:String,val price:Double)