package com.example.kotlinbasics

fun main(){
    var a1 = Car()
    println("The Name of the owner is ${a1.owner}")
    println("The brand is => ${a1.myBrand}")
    println("Maximum speed is ${a1.myMaxSpeed}")

}

class Car(){
    lateinit var owner : String

    val myBrand: String = "BMW"
        // Custom getter
        get() {
            return field.toLowerCase()
        }


    // default setter and getter
    var myModel: String = "M5"
        private set

    var myMaxSpeed: Int = -230
        get() = field
        // Custom Setter
        set(value) {
            field = if(value > 0) value else throw IllegalArgumentException("_maxSpeed must be greater than zero")
        }

    init{
        this.myModel = "M3"
        this.owner = "Frank"
    }
}