package com.example.kotlinbasics

fun main(){
    /*
    Write a for loop that runs from 0 to 10000
Once it's at 9001 it should write "IT'S OVER 9000!!!"
     */
    for(num in 0..10000){
        println("$num")
        if(num == 9001){
            println("IT'S OVER 9000!!!")
            break
        }
    }

    /*
    Write a while loop that checks the humidity (not the humidityLevel).
     The variable humidityLevel starts at 80. The variable humidity is initialized with "humid".
      If it is "humid" then it should reduce the "humidityLevel" by 5 and print "humidity decreased"
Once the humidityLevel is below 60 it should print "it's comfy now" and set the humidity to "comfy"
     */

    var humidityLevel = 80
    var humidity = "humid"
    while(humidity == "humid"){
        humidityLevel -= 5
        println("humidity decreased")
        if(humidityLevel < 60){
            humidity="comfy"
            println("it's comfy now")
        }
    }
}