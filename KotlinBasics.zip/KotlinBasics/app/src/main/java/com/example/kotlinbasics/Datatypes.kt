package com.example.kotlinbasics

fun main(){
    var str: String = "Android Masterclass"
    var floatVal: Float = 13.37F
    var doubleVal: Double = 3.14159265358979
    var age : Int = 25
    var year: Int = 2020
    var longVal : Long = 18881234567
    var boolValue:Boolean=true
    var charValue:Char='A'
}