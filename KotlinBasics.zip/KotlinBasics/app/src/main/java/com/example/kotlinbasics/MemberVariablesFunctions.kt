package com.example.kotlinbasics

fun main(){
    var john = Person("John","Doe",78)
    john.hobby = "Playing Cricket"
    john.setHobby()
    john.showAge()
}
class Person(FirstName:String,LastName:String){
    //Member variables
    var age:Int?=null
    var firstName:String?=null
    var hobby : String = "Watching Movies"
    fun setHobby(){
        println("My hobby is to $hobby")
    }
    //Member constructor
    constructor(FirstName: String,LastName: String,age:Int):this(FirstName,LastName){
        this.age=if(age>0) age else throw java.lang.IllegalArgumentException("Age must be greater than 0")
        this.firstName = FirstName
    }
    //showAge
    fun showAge(){
        println("$firstName\'s age is $age")
    }
}