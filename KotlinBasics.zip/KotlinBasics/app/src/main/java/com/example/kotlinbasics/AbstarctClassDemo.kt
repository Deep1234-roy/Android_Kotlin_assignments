package com.example.kotlinbasics

abstract class Mammal(private val name:String,private val origin:String,private val weight:Double){
    abstract var maxSpeed:Double

    abstract fun run()
    abstract fun breadth()

    fun displayDetails(){
        println("Name => $name, Origin => $origin, Weight => $weight and the Max Speed is => $maxSpeed")
    }
}

class Human(name:String, origin: String, weight: Double, override var maxSpeed: Double):Mammal(name, origin, weight){
    override fun run() {
        println("Human needs 2 legs")
    }

    override fun breadth() {
        println("Human can Breadth!!")
    }
}

fun main(){
    var deep = Human("Deep Roy","India",66.90,50.90)
    deep.run()
    deep.breadth()
    deep.maxSpeed = 78.90
}