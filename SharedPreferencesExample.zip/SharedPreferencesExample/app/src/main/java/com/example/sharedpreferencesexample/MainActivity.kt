package com.example.sharedpreferencesexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.sharedpreferencesexample.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val sharedPrefernce = getSharedPreferences("myPref", MODE_PRIVATE)
        val editor = sharedPrefernce.edit()

        binding.apply {
            btnSave.setOnClickListener {
                val userName = etUsername.text.toString()
                val email = etEmail.text.toString()

                //For saving the data in SharedPreferences
                editor.apply {
                    putString("user_name",userName)
                    putString("email",email)
                    apply()
                }
            }
            btnLoad.setOnClickListener {
                //for loading/displaying/getting the data from the sharedPrefernces
                val username = sharedPrefernce.getString("user_name",null)
                val email = sharedPrefernce.getString("email",null)
                tvUsername.text = username
                tvEmail.text=email
            }
        }
    }
}