package com.example.cityshower.model

data class City(
    val name:String,
    val img: Int,
    val population: Int
)
