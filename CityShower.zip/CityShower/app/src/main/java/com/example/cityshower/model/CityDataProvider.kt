package com.example.cityshower.model

import com.example.cityshower.R

class CityDataProvider {
    private val cities = arrayListOf<City>()

    init {
        cities.add(City("Kolkata", R.drawable.kolkata,200000))
        cities.add(City("Jaypur",R.drawable.jaypur,578000))
        cities.add(City("Noida",R.drawable.noida,4478990))
        cities.add(City("Patna",R.drawable.patna,789999))
        cities.add(City("Pune",R.drawable.pune,500000))
    }

    fun getCities(): ArrayList<City> {
        return cities
    }
}