package com.example.cityshower.viewModel

import android.os.Handler
import android.os.Looper
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.cityshower.model.City
import com.example.cityshower.model.CityDataProvider

class CityViewModel: ViewModel() {

    private val cityDaya = MutableLiveData<City>()
    private val cities = CityDataProvider().getCities()
    private var currentIndex = 0
    private val delay = 2000L

    init {
        loop()
    }

    fun getCityData(): LiveData<City> {
        return cityDaya
    }
    private fun loop(){
        Handler(Looper.getMainLooper()).postDelayed({updateCity()},delay)
    }
    //Update Current City
    private fun updateCity(){
        currentIndex++
        currentIndex %= cities.size
        cityDaya.value = cities[currentIndex]

        loop()
    }
}