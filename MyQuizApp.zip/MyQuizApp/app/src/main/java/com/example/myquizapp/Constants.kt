package com.example.myquizapp

object Constants {

    const val USER_NAME: String = "user_name"
    const val TOTAL_QUESTIONS: String = "total_questions"
    const val CORRECT_ANSWERS: String = "correct_answers"
    fun getQuestions():ArrayList<Question>{
        val questionList=ArrayList<Question>()
        val que1 =  Question(
            1,"Who is the Prime Minister of India?",
            "Mamata Banerjee","Rahul Gandhi",
            "Narendra Modi","P.V Ramanujan",3
        )
        questionList.add(que1)
        val que2 =  Question(
            2,"How many months a year?",
            "Twelve","Nine",
            "Eleven","Four",1
        )
        questionList.add(que2)
        val que3 =  Question(
            3,"What is the Name of Deepika Padukone's Husband?",
            "Ranbir Kapoor","Ranveer Singh",
            "Kartick Aryan","Sidhdant Chaturvedi",2
        )
        questionList.add(que3)
        val que4 =  Question(
            4,"Nagpur is famous for which fruit?",
            "Banana","Apple",
            "Guava","Orange",4
        )
        questionList.add(que4)
        val que5 =  Question(
            5,"Pink city is in which state?",
            "Hariyana","Rajasthan",
            "West Bengal","Karnataka",2
        )
        questionList.add(que5)
        return questionList
    }
}