package com.example.roomdemo

import android.app.AlertDialog
import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.roomdemo.databinding.ActivityMainBinding
import com.example.roomdemo.databinding.DialogUpdateBinding
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private var binding:ActivityMainBinding?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding?.root)
        val employeeDao = (application as EmployeeApp).db.employeeDao()
        binding?.btnAdd?.setOnClickListener {
            addRecord(employeeDao)

        }

        lifecycleScope.launch {
            employeeDao.fetchAllEmployees().collect{
                val list = ArrayList(it)
                setUpDataIntoRecyclerView(list,employeeDao)
            }
        }
    }
    fun addRecord(employeeDao: EmployeeDao){
        var name = binding?.etName?.text.toString()
        var email = binding?.etEmailId?.text.toString()

        if(email.isNotEmpty() && name.isNotEmpty()){
            lifecycleScope.launch {
                employeeDao.insertEmployee(EmployeeEntity(name = name, email = email))
                Toast.makeText(applicationContext,"Record Saved!!",Toast.LENGTH_LONG).show()
                binding?.etName?.text?.clear()
                binding?.etEmailId?.text?.clear()
            }
        }else{
            Toast.makeText(
                applicationContext,"Name/Email can't be empty!!",
                Toast.LENGTH_LONG
            ).show()
        }
    }
    private fun setUpDataIntoRecyclerView(employeeList:ArrayList<EmployeeEntity>,employeeDao: EmployeeDao){
        if(employeeList.isNotEmpty()){
            val itemAdapter = ItemAdapter(employeeList,
                {
                    updateId ->
                    updateRecordDialog(updateId,employeeDao)
                },
                {
                    deleteId ->
                    deleteAlertRecordDialog(deleteId,employeeDao)
                }
                )
            binding?.rvItemList?.layoutManager = LinearLayoutManager(this)
            binding?.rvItemList?.adapter = itemAdapter
            binding?.rvItemList?.visibility = View.VISIBLE
            binding?.tvNoRecordsAvailable?.visibility=View.GONE
        }else{
            binding?.rvItemList?.visibility = View.GONE
            binding?.tvNoRecordsAvailable?.visibility=View.VISIBLE
        }
    }

    private fun updateRecordDialog(id:Int,employeeDao: EmployeeDao){
        val updateDialog = Dialog(this, R.style.Theme_Dialog)
        updateDialog.setCancelable(false)
        val binding = DialogUpdateBinding.inflate(layoutInflater)
        updateDialog.setContentView(binding.root)

        lifecycleScope.launch {
            employeeDao.fetchEmployeeById(id).collect{
                if(it != null){
                    binding.etUserName.setText(it.name)
                    binding.etUpdateEmailID.setText(it.email)
                }
            }
        }
        binding.tvUpdate.setOnClickListener {
            val name = binding.etUserName.text.toString()
            val email = binding.etUpdateEmailID.text.toString()
            if(name.isNotEmpty() && email.isNotEmpty()){
                lifecycleScope.launch {
                    employeeDao.updateEmployee(EmployeeEntity(id,name,email))
                    Toast.makeText(applicationContext,"Record Updated!!",Toast.LENGTH_LONG).show()
                    updateDialog.dismiss()
                }
            }else{
                Toast.makeText(applicationContext,"Name or Email can't be empty!!",Toast.LENGTH_LONG).show()
            }
        }
        binding.tvCancel.setOnClickListener {
            updateDialog.dismiss()
        }
        updateDialog.show()
    }
    private fun deleteAlertRecordDialog(id:Int,employeeDao: EmployeeDao){
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Delete Record")
        builder.setIcon(android.R.drawable.ic_dialog_alert)
        builder.setPositiveButton("Yes"){dialogInterface,_ ->
            lifecycleScope.launch {
                employeeDao.deleteEmployee(EmployeeEntity(id))
                Toast.makeText(
                    applicationContext,
                    "Record Deleted",
                    Toast.LENGTH_LONG
                ).show()
                dialogInterface.dismiss()
            }
        }
        builder.setNegativeButton("No"){dialogInterface,_ ->
            dialogInterface.dismiss()
        }
        val alertDialog: AlertDialog = builder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }
}