package com.example.roomdemo

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.roomdemo.databinding.ItemsRowBinding

class ItemAdapter(private val items: ArrayList<EmployeeEntity>,
                  private val updateListener:(id:Int)->Unit,
                  private val deleteListener:(id:Int)->Unit,
                  ):RecyclerView.Adapter<ItemAdapter.ViewHolder>() {
    inner class ViewHolder(val itemsRowBinding: ItemsRowBinding):RecyclerView.ViewHolder(itemsRowBinding.root) {
        val llMain = itemsRowBinding.llMain
        val tvName = itemsRowBinding.tvName
        val tvEmail = itemsRowBinding.tvEmail
        val ivEdit = itemsRowBinding.ivEdit
        val ivDelete = itemsRowBinding.ivDelete
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemViewHolder = ItemsRowBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ViewHolder(itemViewHolder)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val context = holder.itemView.context
        val item = items[position]
        holder.tvName.text = item.name
        holder.tvEmail.text = item.email

        if(position % 2 == 0){
            holder.llMain.setBackgroundColor(ContextCompat.getColor(holder.itemView.context,R.color.lightGrey))
        }else{
            holder.llMain.setBackgroundColor(ContextCompat.getColor(context,R.color.white))
        }

        holder.ivEdit.setOnClickListener {
            updateListener(item.id)
        }
        holder.ivDelete.setOnClickListener {
            deleteListener(item.id)
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }
}