package com.example.samplelogin.ui.auth.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import com.example.samplelogin.R
import com.example.samplelogin.databinding.ActivityLoginBinding
import com.example.samplelogin.databinding.ActivityRegisterBinding
import com.example.samplelogin.ui.auth.AuthViewModel
import com.example.samplelogin.util.toast

class RegisterActivity : AppCompatActivity() {
//    private var binding: ActivityRegisterBinding?=null
    lateinit var viewModel: AuthViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        binding = ActivityRegisterBinding.inflate(layoutInflater)
//        setContentView(binding?.root)
        val binding: ActivityRegisterBinding = DataBindingUtil.setContentView(this,R.layout.activity_register)
        val viewModel = ViewModelProviders.of(this).get(AuthViewModel::class.java)

        binding?.loginBtn?.setOnClickListener {
            val intent = Intent(this@RegisterActivity,LoginActivity::class.java)
            startActivity(intent)
        }

        binding?.buttonSignUp?.setOnClickListener {
            if(viewModel.onSignUpButtonClicked(binding.editTextEmail.text.toString(),binding.editTextName.text.toString(),binding.editTextPassword.text.toString(),binding.editTextPasswordConfirm.text.toString())){
                Toast.makeText(this@RegisterActivity,"You have registered Successfully!!",Toast.LENGTH_LONG).show()
                val intent = Intent(this@RegisterActivity,LoginActivity::class.java)
                intent.putExtra("name",binding.editTextName.text.toString())
                intent.putExtra("email",binding.editTextEmail.text.toString())
                intent.putExtra("password",binding.editTextPassword.text.toString())
                startActivity(intent)
            }else{
            Toast.makeText(this@RegisterActivity,"Please fill all fields\n Passwords and Confirm Password should be same",Toast.LENGTH_LONG).show()
        }

        }
    }
}