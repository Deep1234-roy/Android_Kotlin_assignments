package com.example.samplelogin.ui.auth

interface AuthListener {
    fun onStared()
    fun onSuccess(msg: String)
    fun onFailure(msg:String)
}