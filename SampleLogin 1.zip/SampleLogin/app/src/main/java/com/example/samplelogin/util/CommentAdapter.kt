package com.example.samplelogin.util

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.samplelogin.databinding.ItemCommentsBinding
import com.example.samplelogin.ui.auth.AuthViewModel
import com.example.samplelogin.ui.model.Comment

class CommentAdapter:RecyclerView.Adapter<CommentAdapter.ViewHolder>() {
    //lateinit var viewModel: AuthViewModel
    private var commentList: List<Comment>?= null
    inner class ViewHolder(val itemBinding:ItemCommentsBinding):RecyclerView.ViewHolder(itemBinding.root) {
        fun bindItem(comments:Comment){
            itemBinding.tvName.text = comments.name
            itemBinding.tvComment.text = comments.email
        }
    }

//    fun getLiveComments():LiveData<List<Comment>>{
//        liveComments = viewModel.getCommentsResponseLiveData()
//        return liveComments
//    }

    fun setResults(results: List<Comment>) {
        commentList = results
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val commentView = ItemCommentsBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ViewHolder(commentView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val comment = commentList?.get(position)
        holder.bindItem(comment!!)
    }

    override fun getItemCount(): Int {
        return commentList!!.size
    }
}