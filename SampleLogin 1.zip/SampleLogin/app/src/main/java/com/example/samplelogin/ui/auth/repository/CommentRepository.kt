package com.example.samplelogin.ui.auth.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.samplelogin.ui.auth.network.CommentClient
import com.example.samplelogin.ui.model.Comment
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CommentRepository {
    lateinit var commentLiveData : MutableLiveData<List<Comment>>
    private lateinit var commentClient: CommentClient
    init {
        commentLiveData = MutableLiveData<List<Comment>>()
        commentClient = CommentClient()
        commentClient.getComments().GetAllComments().enqueue(object : Callback<List<Comment>>{
            override fun onResponse(call: Call<List<Comment>>, response: Response<List<Comment>>) {
                commentLiveData.postValue(response.body())
            }

            override fun onFailure(call: Call<List<Comment>>, t: Throwable) {
                commentLiveData.postValue(null)
            }

        })
    }
    fun getUsersLiveComments():LiveData<List<Comment>>{
        return commentLiveData
    }
}