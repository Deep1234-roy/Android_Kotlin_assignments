package com.example.samplelogin.ui.auth.network

import com.example.samplelogin.ui.model.Comment
import retrofit2.Call
import retrofit2.http.GET

interface CommentInterface {

    @GET("comments")
    fun GetAllComments(): Call<List<Comment>>
}