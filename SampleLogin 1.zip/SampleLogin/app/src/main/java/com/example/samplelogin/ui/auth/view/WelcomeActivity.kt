package com.example.samplelogin.ui.auth.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.samplelogin.databinding.ActivityWelcomeBinding
import com.example.samplelogin.ui.auth.AuthViewModel
import com.example.samplelogin.ui.model.Comment
import com.example.samplelogin.ui.model.CommentList
import com.example.samplelogin.util.CommentAdapter

class WelcomeActivity : AppCompatActivity() {
    private var binding: ActivityWelcomeBinding? = null
    private var authViewModel: AuthViewModel?=null
    lateinit var commentAdapter: CommentAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding?.root)
        setSupportActionBar(binding?.toolBarAddPlace)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding?.toolBarAddPlace?.setNavigationOnClickListener {
            onBackPressed()
        }
        binding?.tvName?.text = intent.getStringExtra("userName")
        commentAdapter = CommentAdapter()
        authViewModel = ViewModelProviders.of(this)[AuthViewModel::class.java]
        authViewModel?.init()
//        commentAdapter = CommentAdapter(CommentList.listOfComments)
        authViewModel?.getCommentsResponseLiveData()?.observe(this, object : Observer<List<Comment>> {
            override fun onChanged(commentList: List<Comment>) {
                commentAdapter.setResults(commentList)
            }
        })
        binding?.showAllCommentsBtn?.setOnClickListener {
            binding?.commentRecyclerView?.adapter = commentAdapter
            binding?.commentRecyclerView?.layoutManager = LinearLayoutManager(this)
        }
    }

}