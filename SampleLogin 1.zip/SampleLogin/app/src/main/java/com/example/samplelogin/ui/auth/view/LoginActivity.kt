package com.example.samplelogin.ui.auth.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import com.example.samplelogin.R
import com.example.samplelogin.databinding.ActivityLoginBinding
import com.example.samplelogin.ui.auth.AuthViewModel

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivityLoginBinding = DataBindingUtil.setContentView(this,R.layout.activity_login)
//        val viewModel = ViewModelProviders.of(this).get(AuthViewModel::class.java)
//        binding.viewmodel = viewModel
        val nameMsg = intent.getStringExtra("name")
        val userMail = intent.getStringExtra("email")
        val userPassword = intent.getStringExtra("password")
        binding.buttonSignIn.setOnClickListener {
            if(binding.editTextEmail.text.toString().equals(userMail.toString()) && binding.editTextPassword.text.toString().equals(userPassword.toString())){
                Toast.makeText(this,"Login Successful",Toast.LENGTH_SHORT).show()
                val intent = Intent(this,WelcomeActivity::class.java)
                intent.putExtra("userName",nameMsg.toString())
                startActivity(intent)
                binding.editTextEmail.text.clear()
                binding.editTextPassword.text.clear()
            }else{
                Log.i("ShowValue->",binding.editTextEmail.toString())
                Toast.makeText(this,"Please Enter valid Email and Password!!",Toast.LENGTH_SHORT).show()
                binding.editTextEmail.text.clear()
                binding.editTextPassword.text.clear()
            }
        }

        binding.btnRegister.setOnClickListener {
            val intent = Intent(this@LoginActivity,RegisterActivity::class.java)
            startActivity(intent)
        }

    }

//    override fun onStared() {
//        findViewById<ProgressBar>(R.id.progress_bar).show()
//
//    }
//
//    override fun onSuccess(msg: String) {
//        toast(msg)
//    }
//
//    override fun onFailure(msg: String) {
//        findViewById<ProgressBar>(R.id.progress_bar).hide()
//        toast(msg)
//    }

}