package com.example.samplelogin.ui.auth

import android.content.Intent
import android.view.View
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.samplelogin.R
import com.example.samplelogin.data.repository.UserRepository
import com.example.samplelogin.databinding.ActivityLoginBinding
import com.example.samplelogin.ui.auth.repository.CommentRepository
import com.example.samplelogin.ui.auth.view.WelcomeActivity
import com.example.samplelogin.ui.model.Comment

class AuthViewModel: ViewModel() {
    lateinit var commentRepository: CommentRepository
    lateinit var commentLiveResponseData: LiveData<List<Comment>>

    var isSignUp:Boolean? = null
    fun init(){
        commentRepository= CommentRepository()
        commentLiveResponseData = commentRepository.getUsersLiveComments()
    }


    fun getCommentsResponseLiveData(): LiveData<List<Comment>> {
        return commentLiveResponseData
    }




    //Need to pass the name parameter so that from Register activity we can pass the name parameter
    fun onSignUpButtonClicked(email:String,name:String,password:String,confirmPassword:String):Boolean{
        return if(email.toString().isNotEmpty() && name.toString().isNotEmpty() && password.toString().isNotEmpty() && confirmPassword.toString().isNotEmpty()){
            if(password == confirmPassword){
                isSignUp = true
                isSignUp!!
            }else{
                isSignUp = false
                isSignUp!!
            }
        }else{
            isSignUp = false
            isSignUp!!
        }
        }
    }
