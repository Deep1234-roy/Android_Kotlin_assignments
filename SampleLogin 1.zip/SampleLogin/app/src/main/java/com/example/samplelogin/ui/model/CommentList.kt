package com.example.samplelogin.ui.model

object CommentList {
    val listOfComments = listOf<Comment>(
        Comment(1,100,"Deep Roy","deep.roy@gmail.com","This is Really nice!!"),
        Comment(2,101,"Abhishek Patil","abhi@gmail.com","Wow!!"),
        Comment(3,102,"Pratusha Pandey","pandey.pratusha@gmail.com","Beautiful!!"),
        Comment(4,103,"Jiban Bisaws","jiban@gmail.com","This is amazing view"),
        Comment(5,104,"Hridoy Khan","hridoy@gmail.com","Absolutely gorgeous"),
        Comment(6,105,"Srinath Thakur","srinath.thakur@gmail.com","Divine gorgeous!!"),
        Comment(7,106,"Ditikhsha Patra","ditikhsha.patra@gmail.com","Nice one!!"),
        Comment(8,107,"Kanchan Saha","kanchan233@gmail.com","View is good, Candid one I guess"),
        Comment(9,108,"Lavkush Gupta","lavkush@gmail.com","Wow, Amazing!!"),
        Comment(10,109,"Hardik Mishra","hardik.mishra@gmail.com","After a long time, see the amazing one!!")

    )
}