package com.example.msgshareapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var showToast = findViewById<Button>(R.id.btnShowToast)
        showToast.setOnClickListener{
            Log.i("MainActivity","Button was clicked!")
        }

    }
}