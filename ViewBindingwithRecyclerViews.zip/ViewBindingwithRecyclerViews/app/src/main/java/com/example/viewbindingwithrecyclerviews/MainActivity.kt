package com.example.viewbindingwithrecyclerviews

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.viewbindingwithrecyclerviews.adapter.TaskAdapter
import com.example.viewbindingwithrecyclerviews.databinding.ActivityMainBinding
import com.example.viewbindingwithrecyclerviews.model.TaskList

class MainActivity : AppCompatActivity() {
    private var binding: ActivityMainBinding?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding?.root)
        val adapter = TaskAdapter(TaskList.listOfTask)
        binding?.taskRv?.adapter = adapter
        binding?.taskRv?.layoutManager = LinearLayoutManager(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        binding = null
    }
}