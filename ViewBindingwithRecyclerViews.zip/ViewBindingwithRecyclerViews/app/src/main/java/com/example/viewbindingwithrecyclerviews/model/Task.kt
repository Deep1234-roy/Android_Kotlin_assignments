package com.example.viewbindingwithrecyclerviews.model

data class Task(val title:String,val timestamp: String)
