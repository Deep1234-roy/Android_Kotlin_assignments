package com.example.viewbindingwithrecyclerviews.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.viewbindingwithrecyclerviews.databinding.ItemContentBinding
import com.example.viewbindingwithrecyclerviews.model.Task
import com.example.viewbindingwithrecyclerviews.model.TaskList

class TaskAdapter(private val taskList: List<Task>): RecyclerView.Adapter<TaskAdapter.ViewHolder>() {
    inner class ViewHolder(val itemBinding: ItemContentBinding): RecyclerView.ViewHolder(itemBinding.root) {
        fun bindItem(task: Task){
            itemBinding.titleTV.text = task.title
            itemBinding.timeTV.text = task.timestamp
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val taskView = ItemContentBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ViewHolder(taskView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val task = taskList[position]
        holder.bindItem(task)
    }

    override fun getItemCount(): Int {
        return taskList.size
    }
}