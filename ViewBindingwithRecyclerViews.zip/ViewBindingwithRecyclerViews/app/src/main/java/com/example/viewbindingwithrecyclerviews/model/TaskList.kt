package com.example.viewbindingwithrecyclerviews.model

//although you can get the data from Room data base or from an API
//here just to keep it simple, we stored a list of tasks inside the object of task
//-----------------------------Data Source---------------------------------------
object TaskList {

    val listOfTask = listOf<Task>(
        Task("Take a Walk","7:00 am"),
        Task("Eat Breakfast","8:00 am"),
        Task("attend a meeting","9:00 am"),
        Task("Read a Book","12:00 pm"),
        Task("Eat Lunch","2:00 pm"),
        Task("Buy Groceries","4:00 pm"),
        Task("Watch Youtube Videos","6:00 pm"),
        Task("Eat Dinner","8:00 pm"),
        Task("Go to Bed","10:00 pm"),
        Task("Midnight Snacks","1:00 am"),
        Task("Sun rise","05:00 am")
    )
}