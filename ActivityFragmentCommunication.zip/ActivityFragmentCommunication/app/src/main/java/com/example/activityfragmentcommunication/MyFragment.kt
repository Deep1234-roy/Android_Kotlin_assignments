package com.example.activityfragmentcommunication

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment


class MyFragment : Fragment() {

    private lateinit var sendMessages: SendMessages
    private lateinit var tv_frag:TextView
    private lateinit var send:Button

    override fun onAttach(context: Context) {
        super.onAttach(context)
        sendMessages = context as SendMessages
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.fragment_my, container, false)
        tv_frag=view.findViewById(R.id.tv_fragment)
        send=view.findViewById(R.id.btn_send)
        send.setOnClickListener {
            sendMessages.iAmMsg("Hello I am Fragment!!")
        }
        return view

    }

    //Interface -> Fragment to Activity
    interface SendMessages{
        fun iAmMsg(msg:String)
    }

    //RecieveMsg -> Activity to Fragment
    fun RecieveMsg(msg:String){
        tv_frag.text = msg
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment MyFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            MyFragment().apply {
            }
    }
}