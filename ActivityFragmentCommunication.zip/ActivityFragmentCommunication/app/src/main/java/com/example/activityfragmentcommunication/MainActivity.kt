package com.example.activityfragmentcommunication

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity(),MyFragment.SendMessages {
    private lateinit var tv_activity:TextView
    private lateinit var btnSendDataToFragment:Button
    private lateinit var myFragment: MyFragment
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tv_activity=findViewById(R.id.tv_activity)
        btnSendDataToFragment=findViewById(R.id.btn_send_act)
        btnSendDataToFragment.setOnClickListener {
//            val manager:FragmentManager=supportFragmentManager
//            manager.findFragmentById(R.id.tv_fragment)
            val manager = supportFragmentManager
            val myFragment = manager.findFragmentById(R.id.tv_fragment) as MyFragment?
            myFragment?.RecieveMsg("Hi Fragment how are you ?")
        }
    }

    //Recieve data from Fragments
    override fun iAmMsg(msg: String) {
        tv_activity.text = msg
    }
}