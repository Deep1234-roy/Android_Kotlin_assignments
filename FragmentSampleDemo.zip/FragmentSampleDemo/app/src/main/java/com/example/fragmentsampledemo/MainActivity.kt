package com.example.fragmentsampledemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.fragment.app.commit
import androidx.fragment.app.replace

class MainActivity : AppCompatActivity() {
    private lateinit var btnNews: Button
    private lateinit var btnSports: Button
    private lateinit var btnScience: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnNews = findViewById(R.id.btnNews)
        btnSports = findViewById(R.id.btnSports)
        btnScience = findViewById(R.id.btnScience)
        btnNews.setOnClickListener {
            supportFragmentManager.commit {
                replace<NewsFragment>(R.id.fragmentContainerView)
                setReorderingAllowed(true)
                addToBackStack("name")
            }
        }

        //Code for Sports button to swicth Fragments
        btnSports.setOnClickListener {
            supportFragmentManager.commit {
                replace<SportsFragment>(R.id.fragmentContainerView)
                setReorderingAllowed(true)
                addToBackStack("name")
            }
        }

        //Code for Science button to swicth Fragments
        btnScience.setOnClickListener {
            supportFragmentManager.commit {
                replace<ScienceFragment>(R.id.fragmentContainerView)
                setReorderingAllowed(true)
                addToBackStack("name")
            }
        }

    }
}